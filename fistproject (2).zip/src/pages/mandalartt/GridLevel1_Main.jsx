import { useEffect, useState } from "react";
import "./gridLevel1_1.css";
import { patchGridData } from "../../apis/grid";

function GridLevel1_Main({
  projectId,
  normalDataIndex,
  normalData,
  setNormalData,
}) {
  // 현재 선택된 객체의 정보 한개를 보관
  const [isModalOpen, setIsModalOpen] = useState(false);
  // 팝업창에 보여줄 변경 되고 있는 데이터
  const [selectData, setSelectData] = useState(null);
  // 현재 9칸의 데이터를 가지고 있음.
  const [showData, setShowData] = useState(null);
  const [subClear, setSubClear] = useState(0);
  const [color, setColor] = useState(true);
  // 제외 셀
  const exceptionCell = cellId => {
    switch (cellId) {
      case "cell-0-0-1-1":
      case "cell-0-1-1-1":
      case "cell-0-2-1-1":
      case "cell-1-0-1-1":
      case "cell-1-1-1-0":
      case "cell-1-1-1-1":
      case "cell-1-1-1-2":
      case "cell-1-1-0-0":
      case "cell-1-1-0-1":
      case "cell-1-1-0-2":
      case "cell-1-1-2-0":
      case "cell-1-1-2-1":
      case "cell-1-1-2-2":
      case "cell-1-2-1-1":
      case "cell-2-0-1-1":
      case "cell-2-1-1-1":
      case "cell-2-2-1-1":
        setColor(false);
        break;
      default:
        setColor(true);
    }
  };
  const exceptionCellId = [
    "cell-0-0-1-1",
    "cell-0-1-1-1",
    "cell-0-2-1-1",
    "cell-1-0-1-1",
    "cell-1-1-1-0",
    "cell-1-1-1-1",
    "cell-1-1-1-2",
    "cell-1-1-0-0",
    "cell-1-1-0-1",
    "cell-1-1-0-2",
    "cell-1-1-2-0",
    "cell-1-1-2-1",
    "cell-1-1-2-2",
    "cell-1-2-1-1",
    "cell-2-0-1-1",
    "cell-2-1-1-1",
    "cell-2-2-1-1",
  ];

  // 색깔
  const handleClearChange = event => {
    const subSelect = event.target.value;
    setSubClear(subSelect);
  };

  const handleSubmit = async selectData => {
    console.log(projectId);
    // 웹브라우저 새로고침 방지
    projectId.preventDefault();
    const res = await patchGridData(projectId);
    console.log(res.data);
  };

  useEffect(() => {
    setShowData(normalData[normalDataIndex]);
  }, [normalData]);
  // 모달 열기
  const openModal = id => {
    // 선택된 객체 정보 한개를 보관
    console.log(showData.find(item => item.cellId === id));
    const selectDatas = async () => {
      const res = await setSelectData(
        showData.find(item => item.cellId === id),
      );
    };
    // 완료미완료 선택창 제외 셀 cas
    console.log(selectData);
    exceptionCell(id);

    setIsModalOpen(true);
  };

  // 모달 입력값 변경 처리
  const handleModalChange = e => {
    const { name, value } = e.target;
    setSelectData(prevData => ({ ...prevData, [name]: value }));
  };

  // 모달 데이터 저장
  const saveModalData = () => {
    // 9개의 보여지고 있는 데이터를 변경된 데이터로 변경
    const newShowData = showData.map(item => {
      if (item.cellId === selectData.cellId) {
        return { ...item, ...selectData };
      }
      return item;
    });

    // 원본 데이터 참조
    const updatedNormalData = normalData.map(originalItem => {
      // 원본 데이터를 복사하여 수정
      const updatedOriginalItem = originalItem.map(itemNow => {
        const bindedItem = newShowData.find(
          item =>
            item.isbindKey === itemNow.cellId || item.cellId === itemNow.cellId,
        );
        if (bindedItem) {
          return { ...itemNow, title: bindedItem.title };
        }

        return itemNow;
      });
      return updatedOriginalItem;
    });
    console.log(updatedNormalData);
    // const uploadDataForm =  selectData.value =>
    //   ;

    // 원본 데이터와 showData 동기화
    setNormalData(updatedNormalData);
    setShowData(newShowData);
    console.log(selectData);
    // 최신 newShowData로 patch 호출
    patchGridData(selectData);

    // 모달 닫기
    setIsModalOpen(false);
  };

  // useEffect(() => {
  //   patchGridData(showData);
  // }, [patchGridData(showData)]);

  return (
    <div>
      <div className="sub-container">
        {/* 각 셀 */}
        {showData?.map((item, index) => (
          <div
            key={index}
            id={item.cellId}
            onClick={() => openModal(item.cellId)}
            className="sub-item"
            style={{
              backgroundColor: item.bgcolor,
            }}
          >
            {item.title}
          </div>
        ))}
      </div>

      {/* 모달 */}
      {isModalOpen && (
        <div className="modal-overlay">
          <form onSubmit={handleSubmit}>
            <div className="modal">
              <label>
                제목:
                <input
                  type="text"
                  name="title"
                  value={selectData.cellData?.title}
                  onChange={handleModalChange}
                />
              </label>
              <label>
                내용:
                <textarea
                  name="contents"
                  value={selectData.content}
                  onChange={handleModalChange}
                />
              </label>
              <label>
                시작 날짜:
                <input
                  className="planDate"
                  type="date"
                  name="startDate"
                  value={selectData.startdate}
                  onChange={handleModalChange}
                />
              </label>
              <label>
                종료 날짜:
                <input
                  className="planDate"
                  type="date"
                  name="finishDate"
                  value={selectData.enddate}
                  onChange={handleModalChange}
                />
              </label>
              {color && (
                <div className="selectbox">
                  <select value={subClear} onChange={handleClearChange}>
                    <option value="0">미완료</option>
                    <option value="1">완료</option>
                  </select>
                </div>
              )}

              <div className="modal-buttons">
                <button type="submit">전송</button>
                <button onClick={saveModalData}>
                  {selectData.title === undefined ? "저장" : "수정"}
                </button>
                <button onClick={() => setIsModalOpen(false)}>취소</button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

export default GridLevel1_Main;
